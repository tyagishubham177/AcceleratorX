# Failure case: out-of-distribution safety escalation

## Purpose

Test whether the winning **role + constraints** technique remains superior when the task moves from ecommerce operations to a safety-sensitive healthcare workflow.

## New input

```text
At 08:20 IST, a medication-reminder service sent 14 reminders approximately 60 minutes late following a daylight-saving-time configuration change. Delivery timing returned to normal at 08:47 IST.

No missed doses have been confirmed. One user reported taking medication later than usual, but no causal link has been established. The configuration change is a suspected cause, not a confirmed root cause.

The incident occurred in a healthcare workflow. The organisation's operating procedure requires immediate notification to the clinical safety lead when a software incident could plausibly affect medication timing.

The next stakeholder update is scheduled for 10:00 IST.
```

## Winning-technique transcript: role + constraints

## Stakeholder update

At 08:20 IST, medication reminders were delayed by approximately 60 minutes following a configuration change. Reminder delivery returned to normal at 08:47 IST. Fourteen reminders were affected. No missed doses have been confirmed, and the cause remains under investigation. One user reported taking medication later than usual, although a connection to the delay has not been established. The next stakeholder update will be provided at 10:00 IST.

## Internal actions

- Validate the daylight-saving-time configuration as the cause using logs and test replay.
- Confirm delivery status for all 14 reminders.
- Maintain monitoring of reminder timing and delivery queues.
- Block further configuration changes until testing is complete.
- Prepare an approved response for Support before the 10:00 update.


### Score

| Criterion | Score |
|---|---:|
| Evidence fidelity and uncertainty control | 4 |
| Audience fit and tone | 4 |
| Actionability and completeness | 2 |
| **Total** | **10/15** |

## Lower-technique transcript: chain-of-thought / structured reasoning

## Compact reasoning trace

1. Technical service has recovered, but the event may have affected medication timing.
2. No missed doses or causal harm are confirmed, so neither should be claimed.
3. The user report is material safety evidence but remains unverified.
4. The operating procedure explicitly requires immediate clinical-safety notification; this outranks routine engineering follow-up.
5. The suspected configuration cause must remain qualified pending validation.

## Customer/stakeholder update

Between 08:20 and 08:47 IST, 14 medication reminders were delivered approximately 60 minutes late. Reminder timing has returned to normal. No missed doses have been confirmed. One user reported taking medication later than usual, but it has not been established that the delay caused this outcome. We are investigating the daylight-saving-time configuration change as a possible cause and have initiated the required clinical-safety review. The next update will be provided at 10:00 IST.

## Internal engineering action recommendation

- Notify the clinical safety lead immediately and preserve the notification record.
- Contact or route the 14 affected cases through the approved safety follow-up process without making clinical assumptions.
- Preserve logs, timing records, configuration history, and the user report for safety and root-cause review.
- Validate the daylight-saving-time hypothesis through controlled replay and boundary tests.
- Keep the configuration frozen until engineering and clinical-safety review approve release.


### Score

| Criterion | Score |
|---|---:|
| Evidence fidelity and uncertainty control | 5 |
| Audience fit and tone | 4 |
| Actionability and completeness | 5 |
| **Total** | **14/15** |

## Diagnosis

The original role + constraints prompt was optimised for a commerce incident and hard-coded a routine engineering action schema. It produced a polished response but omitted the explicitly required clinical-safety escalation, which is the most important action in the new domain. The structured-reasoning technique examined the new evidence and operating procedure before drafting, so it surfaced the safety lead, evidence preservation, and approved follow-up process. The failure shows that tightly constrained prompts can outperform on a stable task yet become brittle when the task distribution changes.
