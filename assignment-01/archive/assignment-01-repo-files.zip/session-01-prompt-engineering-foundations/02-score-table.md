# Filled score table

| Technique | Evidence | Audience | Actionability | Total | Rationale |
|---|---:|---:|---:|---:|---|
| Zero-shot | 5 | 4 | 4 | **13/15** | Accurate and concise, but the external update retains technical wording and the action plan is slightly less prioritised. |
| Few-shot | 3 | 5 | 4 | **12/15** | Strong format and tone, but it copied an unsupported completion promise from the examples and overstates root-cause confirmation in an action. |
| CoT / structured reasoning | 5 | 4 | 5 | **14/15** | Best evidence audit and action logic; the extra reasoning trace adds length and latency beyond the production output itself. |
| Role + constraints | 5 | 5 | 5 | **15/15** | Best audience separation, uncertainty control, completeness, and production-ready format on the target task. |

## Ranking

1. Role + constraints - 15/15
2. CoT / structured reasoning - 14/15
3. Zero-shot - 13/15
4. Few-shot - 12/15
