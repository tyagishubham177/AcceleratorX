# Chain-of-thought / structured-reasoning prompt

**Model:** GPT-5.6 Thinking (ChatGPT)  
**Temperature:** Platform-managed; exact value not exposed in ChatGPT  
**Run:** First response retained; no regeneration or editing

```text
Analyse the incident step by step before drafting the communication.

First provide a compact, auditable reasoning trace containing:
- confirmed facts,
- hypotheses or unknowns,
- communication risks,
- decisions that the two outputs must reflect.

Then produce:
1. A customer/stakeholder update of no more than 130 words.
2. An internal engineering action recommendation of no more than five bullets.

Do not invent a root cause, completion time, customer outcome, or owner that is not supported by the notes.

INCIDENT NOTES
At 10:05 IST, immediately after version 4.8.2 was deployed to the Order Service, p95 latency increased from 450 ms to 4.8 seconds and 17% of checkout requests timed out.

Rollback started at 10:32 IST and completed at 10:41 IST. Service metrics returned to normal by 10:46 IST.

612 customer checkout attempts were affected. 421 were completed successfully through automatic retry. The remaining 191 require reconciliation.

No data loss has been detected. Root cause is not confirmed. Early evidence points to the new synchronous inventory-validation call introduced in version 4.8.2. Database health and the payment gateway remained normal.

Customer Support has received 37 tickets. The next stakeholder update is scheduled for 14:00 IST.
```
