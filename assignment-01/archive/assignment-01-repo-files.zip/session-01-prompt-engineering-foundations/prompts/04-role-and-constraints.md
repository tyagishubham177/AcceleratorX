# Role + constraints prompt

**Model:** GPT-5.6 Thinking (ChatGPT)  
**Temperature:** Platform-managed; exact value not exposed in ChatGPT  
**Run:** First response retained; no regeneration or editing

```text
You are the incident communications lead and SRE programme manager for a B2B commerce platform.

Your job is to convert technical incident notes into two decision-ready outputs for different audiences.

OUTPUT A - EXTERNAL STAKEHOLDER UPDATE
- Maximum 120 words.
- Calm, factual, and non-defensive.
- State impact, current service status, remaining customer work, and next-update time.
- Use minimal technical jargon.
- Do not identify a root cause unless confirmed.
- Do not promise when unresolved transactions will be completed.
- Do not blame a team, vendor, or component.
- Distinguish service recovery from reconciliation.

OUTPUT B - INTERNAL ACTION RECOMMENDATION
- Maximum five bullets, ordered by priority.
- Cover customer reconciliation, evidence-based diagnosis, monitoring, release control, and support communication.
- Do not assign named owners unless supplied.
- Do not treat a suspected cause as confirmed.
- Each bullet must begin with an action verb.

Use exactly these headings:
## Stakeholder update
## Internal actions

INCIDENT NOTES
At 10:05 IST, immediately after version 4.8.2 was deployed to the Order Service, p95 latency increased from 450 ms to 4.8 seconds and 17% of checkout requests timed out.

Rollback started at 10:32 IST and completed at 10:41 IST. Service metrics returned to normal by 10:46 IST.

612 customer checkout attempts were affected. 421 were completed successfully through automatic retry. The remaining 191 require reconciliation.

No data loss has been detected. Root cause is not confirmed. Early evidence points to the new synchronous inventory-validation call introduced in version 4.8.2. Database health and the payment gateway remained normal.

Customer Support has received 37 tickets. The next stakeholder update is scheduled for 14:00 IST.
```
