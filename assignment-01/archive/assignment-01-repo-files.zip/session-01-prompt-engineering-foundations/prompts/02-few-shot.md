# Few-shot prompt

**Model:** GPT-5.6 Thinking (ChatGPT)  
**Temperature:** Platform-managed; exact value not exposed in ChatGPT  
**Run:** First response retained; no regeneration or editing

```text
Follow the pattern shown in the examples. Produce a customer/stakeholder update of no more than 130 words and an internal engineering action recommendation of no more than five bullets.

EXAMPLE 1
Input: A reporting service was unavailable for 18 minutes after a configuration change. Service was restored by reverting the change. 84 report requests failed; 79 succeeded after retry and five need manual follow-up. Root cause is still being verified. Next update: 16:00.
Output:
Customer update: We experienced an 18-minute interruption to report generation after a configuration change. Service has been restored. Of 84 affected requests, 79 completed after retry and five are being handled manually. We are validating the root cause and will share the next update at 16:00.
Internal actions:
- Complete the five manual follow-ups before the next update.
- Validate the configuration-change hypothesis using deployment and application logs.
- Add a pre-deployment configuration check.

EXAMPLE 2
Input: Notification delivery slowed for 26 minutes. 2,100 notifications were delayed, none were lost, and the queue cleared after capacity was increased. The triggering condition remains unknown. Next update: 11:30.
Output:
Customer update: Notification delivery was delayed for 26 minutes. Capacity was increased and the queue has now cleared. No notifications were lost. We are investigating the triggering condition and expect all follow-up work to be completed before the 11:30 update.
Internal actions:
- Verify queue drain and delivery completion.
- Identify the triggering condition.
- Review autoscaling thresholds.


NOW COMPLETE THIS TASK
At 10:05 IST, immediately after version 4.8.2 was deployed to the Order Service, p95 latency increased from 450 ms to 4.8 seconds and 17% of checkout requests timed out.

Rollback started at 10:32 IST and completed at 10:41 IST. Service metrics returned to normal by 10:46 IST.

612 customer checkout attempts were affected. 421 were completed successfully through automatic retry. The remaining 191 require reconciliation.

No data loss has been detected. Root cause is not confirmed. Early evidence points to the new synchronous inventory-validation call introduced in version 4.8.2. Database health and the payment gateway remained normal.

Customer Support has received 37 tickets. The next stakeholder update is scheduled for 14:00 IST.
```
