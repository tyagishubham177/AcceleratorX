# Pre-committed scoring rubric

**Written before the four runs. It was not changed after seeing the outputs.**

## Evidence fidelity and uncertainty control

| Score | Definition |
|---:|---|
| 1 | Contains multiple factual errors, unsupported claims, or treats a hypothesis as confirmed. |
| 2 | Contains one material error or several risky omissions/inferences. |
| 3 | Mostly accurate, but includes one ambiguous claim or fails to distinguish known, suspected, and unknown information. |
| 4 | Accurate and appropriately qualified, with only a minor omission that does not change the decision. |
| 5 | Fully faithful to the evidence; clearly separates confirmed facts, hypotheses, and unresolved work; invents nothing. |

## Audience fit and tone

| Score | Definition |
|---:|---|
| 1 | Confusing, inappropriate, alarmist, defensive, or unusably technical. |
| 2 | Poorly tailored to one or both audiences; substantial jargon or tone problems. |
| 3 | Generally usable but mixes audiences, is too long, or requires editing. |
| 4 | Clear, calm, professional, and mostly tailored, with a small tone or jargon issue. |
| 5 | External update is concise and reassuring without minimising impact; internal recommendation is direct and operational. |

## Actionability and completeness

| Score | Definition |
|---:|---|
| 1 | Omits current status and practical next steps. |
| 2 | Provides generic actions but misses major operational work. |
| 3 | Covers basic next steps but lacks prioritisation, ownership logic, or an important follow-up item. |
| 4 | Covers impact, recovery, remaining work, next update, and concrete actions with only a minor gap. |
| 5 | Clearly distinguishes service recovery from business reconciliation and gives a prioritised, decision-ready action plan. |

