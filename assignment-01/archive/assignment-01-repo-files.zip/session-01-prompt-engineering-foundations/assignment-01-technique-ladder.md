# Assignment 1: The Technique Ladder - Complete Submission

**Lecture:** Prompt Engineering Foundations  
**Author:** Shubham Tyagi  
**Run date:** 18 July 2026  
**Status:** Completed draft with one disclosed platform limitation

## Goal

Identify the cheapest prompting technique that reliably works for a real business task, rather than assuming that the most elaborate technique is best.

## Business task selected

Convert a technical checkout-service incident into:

1. a concise external stakeholder update; and
2. a prioritised internal engineering action recommendation.

This is representative of software-delivery work where engineering evidence must be converted into clear communication for customers, Support, Operations, and technical teams.

## Controlled task input

The incident notes below were kept identical for all four primary runs.

```text
At 10:05 IST, immediately after version 4.8.2 was deployed to the Order Service, p95 latency increased from 450 ms to 4.8 seconds and 17% of checkout requests timed out.

Rollback started at 10:32 IST and completed at 10:41 IST. Service metrics returned to normal by 10:46 IST.

612 customer checkout attempts were affected. 421 were completed successfully through automatic retry. The remaining 191 require reconciliation.

No data loss has been detected. Root cause is not confirmed. Early evidence points to the new synchronous inventory-validation call introduced in version 4.8.2. Database health and the payment gateway remained normal.

Customer Support has received 37 tickets. The next stakeholder update is scheduled for 14:00 IST.
```

## Run protocol

- The scoring rubric was written before running any technique.
- One first response was retained for each technique.
- The raw outputs were not rewritten after generation.
- All four runs used **GPT-5.6 Thinking (ChatGPT)**.
- Temperature was **Platform-managed; exact value not exposed in ChatGPT**.

See [00-run-metadata.md](./00-run-metadata.md) for the limitation and rerun procedure.

## Deliverables index

- [Pre-committed scoring rubric](./01-scoring-rubric.md)
- [Filled score table](./02-score-table.md)
- [Cost comparison and ship decision](./03-cost-and-ship-decision.md)
- [Prompts](./prompts/)
- [Raw outputs](./raw-outputs/)
- [Failure case](./failure-case/failure-case.md)

## Final result

| Rank | Technique | Score |
|---:|---|---:|
| 1 | Role + constraints | **15/15** |
| 2 | CoT / structured reasoning | **14/15** |
| 3 | Zero-shot | **13/15** |
| 4 | Few-shot | **12/15** |

The **role + constraints** prompt is the recommended production technique for the defined checkout-incident task. It produced the strongest result without the example overhead of few-shot or the generation overhead of the structured-reasoning approach.

The failure case deliberately moved the task into a healthcare safety context. There, the role + constraints prompt fell to **10/15**, while structured reasoning scored **14/15**, because the fixed commerce action schema omitted the required clinical-safety escalation. This establishes the boundary of the winning technique rather than claiming it is universally superior.
