# Session 01 - Prompt Engineering Foundations

This folder contains the completed working package for **Assignment 1: The Technique Ladder**.

Start with [`assignment-01-technique-ladder.md`](./assignment-01-technique-ladder.md). The remaining files preserve the pre-committed rubric, exact prompts, raw outputs, scoring, cost comparison, and failure-case evidence.

## Folder structure

```text
session-01-prompt-engineering-foundations/
├── assignment-01-technique-ladder.md
├── 00-run-metadata.md
├── 01-scoring-rubric.md
├── 02-score-table.md
├── 03-cost-and-ship-decision.md
├── prompts/
│   ├── 01-zero-shot.md
│   ├── 02-few-shot.md
│   ├── 03-chain-of-thought.md
│   └── 04-role-and-constraints.md
├── raw-outputs/
│   ├── 01-zero-shot-output.md
│   ├── 02-few-shot-output.md
│   ├── 03-chain-of-thought-output.md
│   └── 04-role-and-constraints-output.md
└── failure-case/
    └── failure-case.md
```

## Integrity note

The first response for each technique is retained. The scoring rubric was written before the runs. Known platform limitations are disclosed in `00-run-metadata.md` rather than replaced with invented measurements.
