# Cost and latency comparison

Token counts are approximate. Exact wall-clock latency was unavailable in the ChatGPT interface.

| Technique | Prompt tokens (est.) | Output tokens (est.) | Total (est.) | Relative latency |
|---|---:|---:|---:|---|
| Zero-shot | 243 | 303 | 546 | Lowest |
| Few-shot | 597 | 257 | 854 | Highest prompt-processing load |
| CoT / structured reasoning | 317 | 528 | 845 | Highest generation/reasoning load |
| Role + constraints | 450 | 274 | 724 | Moderate |


## Ship decision

For the recurring checkout-incident task, I would ship the **role + constraints** prompt. It achieved the highest score while using less context than few-shot and producing less reasoning overhead than the structured-reasoning approach. The constraints directly target the two highest-risk failure modes: treating a suspected cause as confirmed and confusing service recovery with completion of customer reconciliation. Zero-shot is cheaper and performed well, but it leaves more behaviour to the model and therefore has a larger consistency risk across incidents. The role prompt should be versioned for this task only; the failure case shows that it should not be reused unchanged in a safety-critical domain.
