# Run metadata and integrity note

- **Run date:** 18 July 2026
- **Model for all runs:** GPT-5.6 Thinking (ChatGPT)
- **Temperature for all runs:** Platform-managed; exact value not exposed in ChatGPT
- **Sampling:** One response per technique; first response retained
- **Editing:** Raw-output text was not rewritten after generation
- **Token measurement:** Approximate, calculated as characters divided by four because the ChatGPT interface does not expose tokenizer counts
- **Latency measurement:** Exact wall-clock latency was not exposed; relative latency is reported using prompt/output size and reasoning burden

## Important limitation

The assignment requests a numerical temperature for every run. ChatGPT does not expose or allow control of the active temperature, so the truthful value is recorded as platform-managed and unavailable. If a numerical temperature is an absolute submission requirement, rerun the included prompts once through an API or playground at a fixed temperature (recommended: 0.2), keep the first outputs, and replace the raw transcripts and cost table without changing the pre-committed rubric.
