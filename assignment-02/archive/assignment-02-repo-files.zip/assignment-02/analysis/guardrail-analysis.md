# Prompt versus hard-coded guardrail analysis

## Constraint 1: Refunds above USD 50 require approval

**Decision: enforce outside the model as a hard-coded financial guardrail.**

The prompt should explain the limit and guide the conversation, but it must not be the enforcement point. The v1 attack demonstrated why: the assistant interpreted USD 50 as a per-transaction limit and issued two USD 45 refunds. A production refund API should reject any action that would take the cumulative unapproved amount above USD 50 for the order, customer case, account, or connected incident. It should also require an authenticated approval token for higher amounts, use idempotency keys, prevent concurrent race-condition bypasses, and write an immutable audit record. The model may recommend or request a refund; only the policy service should authorise and execute it.

## Constraint 2: Never discuss competitors

**Decision: enforce primarily in the prompt, supported by evaluation and monitoring rather than a simple hard-coded keyword block.**

Competitor discussion is semantic and context-dependent. A user may mention a competitor while reporting a migration problem, quoting an email, or asking for vendor-neutral selection criteria. A hard block on company names would create false positives, while aliases, misspellings, translations, and encodings would bypass it. The prompt is better suited to distinguish an allowed acknowledgement from a prohibited comparison, ranking, or criticism. Production support should add an output classifier, logging, and periodic adversarial evaluation, but the response decision should remain contextual. If the business treats any competitor reference as legally sensitive, a human-review route can be added without pretending that string matching solves the policy.

## Conclusion

Use prompts for semantic behaviour and communication boundaries. Use deterministic systems for money, authorisation, data access, and irreversible actions. The model can explain policy; it should not be trusted to enforce transactional policy by itself.
