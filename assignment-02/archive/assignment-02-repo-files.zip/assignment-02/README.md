# Assignment 2: Build It, Then Break It

**Topic:** Context Engineering  
**Status:** Completed

This assignment designs a layered support-assistant system prompt, attacks it across ten adversarial categories, records every break, patches the observed weaknesses in v2, and separates prompt-level behaviour from controls that require deterministic enforcement.

## Result

- V1 passed **4/10** attack categories.
- V1 broke in **6/10**, including two critical failures: split-refund bypass and customer-data exposure.
- Six targeted v2 patches were added.
- All six broken categories held in the documented v2 retest.
- Refund limits were classified as a hard-coded guardrail; competitor discussion remained primarily a prompt-level semantic constraint.

## Files

- [Complete submission](./solution/complete-submission.md)
- [V1 system prompt](./prompts/v1-system-prompt.md)
- [V2 system prompt](./prompts/v2-system-prompt.md)
- [V1 red-team transcripts](./transcripts/v1-red-team-transcripts.md)
- [V2 targeted retests](./transcripts/v2-retest-transcripts.md)
- [Break log](./analysis/break-log.md)
- [V1 to V2 diff](./analysis/v1-v2-diff.md)
- [Guardrail analysis](./analysis/guardrail-analysis.md)
- [Run metadata](./metadata/run-metadata.md)

## Integrity note

The exercise used fictional company and customer data in a controlled sandbox. No live product was attacked. A successful prompt retest is treated as evidence, not proof of deterministic safety.
