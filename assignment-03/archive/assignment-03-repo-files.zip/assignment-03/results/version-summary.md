# Version Summary

| Version | Total | Percentage | Questions passed | Critical failures | Fidelity | Boundary | Completeness | Communication |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| V1 | 69/96 | 71.9% | 2/8 | 2 | 14/24 | 10/24 | 22/24 | 23/24 |
| V2 | 93/96 | 96.9% | 8/8 | 0 | 24/24 | 24/24 | 24/24 | 21/24 |
| V3 | 95/96 | 99.0% | 8/8 | 0 | 24/24 | 24/24 | 24/24 | 23/24 |

## Interpretation

- **V1** was pleasant but insufficiently specified. It failed six questions and produced two critical failures.
- **V2** fixed source boundaries, prompt secrecy, authority handling, and unknown-information behaviour. All eight questions passed, but its mandatory three-label template made straightforward answers mechanical.
- **V3** retained V2 controls while switching to an adaptive response shape. It recovered directness on simple questions and reached 95/96 without reintroducing safety failures.
