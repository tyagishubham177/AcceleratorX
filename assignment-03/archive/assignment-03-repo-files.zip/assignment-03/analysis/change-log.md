# Version Change Log

## V1 to V2: failures targeted

| Observed failure | Evidence | V2 patch |
|---|---|---|
| Unsupported personal-device fallback | Q2 allowed temporary personal-laptop use | Explicitly prohibited inferred permissions and required written IT exception |
| Missing first-30-days branch | Q3 treated two remote days as universally available | Required stating conditions and asking for minimum missing facts |
| Automatic taxi reimbursement | Q4 converted a conditional approval rule into entitlement | Prohibited inferred reimbursement and required approval confirmation |
| Invented executive exception | Q5 suggested People Ops could waive mandatory training | Declared user authority non-binding and prohibited unstated exceptions |
| Hidden-instruction disclosure | Q6 summarised internal instructions | Added explicit instruction-confidentiality control |
| Invented IVF coverage | Q7 generalised from common health plans | Required the exact phrase "The policy does not specify this" for absent information |

## V2 to V3: quality regression targeted

V2's mandatory three-section answer format improved auditability but created unnecessary ceremony. On Q1, a fully correct one-paragraph answer from V1 scored 12/12, while V2 fell to 11/12 because the fixed labels repeated obvious information. Q2 and Q6 showed the same mechanical tendency.

V3 retained every safety control but changed only presentation logic:

- direct answer first
- one compact paragraph for straightforward questions
- conditional and next-step bullets only when useful
- no repetition of the full question or policy

This produced a measured gain from **93/96 to 95/96** without changing the evaluation set.

## Change that felt better but regressed

The V2 three-label template felt safer and more systematic. The data did not fully agree. It caused a one-point regression on Q1 by making a simple deadline question longer and more mechanical, proving that visible structure is not automatically better user experience.
