# Run Metadata and Reproducibility

- **Model:** GPT-5.6 Thinking (ChatGPT)
- **Temperature:** Platform-managed; numerical value not exposed in ChatGPT
- **Other sampling parameters:** Not exposed in ChatGPT
- **Tools:** None
- **Ground truth:** Fictional Northstar Labs onboarding policy v1.0
- **Evaluation set:** Eight frozen questions, unchanged across all versions
- **Response policy:** One first response retained per prompt-question pair; no regeneration or post-editing
- **Tracking method:** Equivalent tracking workbook (`assignment-03-evaluation-tracker.xlsx`) plus CSV export
- **Timezone:** Asia/Kolkata (IST)
- **Batch start:** 2026-07-19T00:41:53+05:30
- **Prompt hashes:** V1 `9c01cc626c1c`, V2 `37db82b82a56`, V3 `e85c82ca40a2`

## Important limitation

ChatGPT does not expose a numerical temperature or complete API trace. The submission records that limitation rather than inventing a value. For production validation, the proposed v4 gate requires API runs with explicit sampling parameters and repeated trials.

## Scoring limitation

The current scores are rubric-based single-reviewer judgments. A production evaluation should add a second independent reviewer or deterministic checks for policy citations, absent-information handling, and forbidden claims.
