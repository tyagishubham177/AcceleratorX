# Northstar Labs Employee Onboarding Policy - Evaluation Ground Truth

**Document type:** Fictional policy one-pager for controlled prompt evaluation  
**Version:** 1.0  
**Scope:** New-hire onboarding only

1. **Day-one orientation.** Orientation begins at 09:30 local time on the employee's first working day. Office or virtual joining details are sent in the welcome email.
2. **Identity verification.** A government-issued identity document must be verified by 12:00 on day one.
3. **Laptop delivery and device use.** Office-based hires collect their company laptop on day one. Remote hires should receive it by courier one business day before joining. Personal devices may not be used for company work unless IT grants a written exception.
4. **Account security setup.** Multi-factor authentication and the company password manager must be configured by the end of day one.
5. **Security training.** Security and privacy training must be completed within five business days of joining.
6. **Code of Conduct.** The Code of Conduct acknowledgement is due within three business days of joining.
7. **Payroll setup.** Bank and tax details are due by the end of the third business day. Late submission may delay the first salary payment.
8. **Benefits enrollment.** Benefits enrollment must be completed within ten calendar days of joining. Coverage is not automatically added after a missed deadline; the employee must contact People Ops.
9. **Health insurance start.** Health insurance begins on the date of joining once enrollment is approved.
10. **Remote-work rule.** For the first 30 calendar days, new hires work from their assigned office unless both the manager and People Ops approve a written exception. After day 30, employees may work remotely up to two days per week with manager approval.
11. **Working hours.** Core collaboration hours are 10:00 to 16:00 local time. The standard workday is nine hours including a one-hour meal break.
12. **Leave during first 30 days.** Planned leave during the first 30 calendar days requires manager approval. Sick and emergency leave follow the normal leave process.
13. **Business expenses.** Business expenses generally require pre-approval. Itemised receipts are required for claims above INR 500, and claims must be submitted within 15 calendar days.
14. **Local and late-night transport.** Normal travel to the assigned office is not reimbursable. Late-night transport may be reimbursed only when it is arranged or approved by the employee's manager or People Ops.
15. **Contacts and buddy.** People Ops assigns an onboarding buddy within two business days. IT support: helpdesk@northstarlabs.test. People Ops: peopleops@northstarlabs.test.

> This fictional document is the sole ground truth for Assignment 3. Information not stated here must be treated as unknown.
