# Assignment 3: Prompting as an Engineering Practice

**Topic:** Prompt Lab + evaluation tracking  
**Status:** Completed

## Purpose

Develop one onboarding-assistant prompt through three measured versions. Every revision is tied to observed failures in a frozen evaluation set rather than subjective preference.

## Scenario

A fictional Northstar Labs Employee Onboarding Assistant answers policy questions about benefits, IT setup, remote work, expenses, and deadlines. The 15-fact policy one-pager is the sole ground truth.

## Results

| Version | Score | Pass rate | Critical failures |
|---|---:|---:|---:|
| V1 | 69/96 (71.9%) | 2/8 | 2 |
| V2 | 93/96 (96.9%) | 8/8 | 0 |
| V3 | 95/96 (99.0%) | 8/8 | 0 |

V1 failed on unsupported device use, remote-work conditions, taxi reimbursement, executive authority, hidden-instruction protection, and absent benefit coverage. V2 fixed those source and security boundaries. V3 then removed V2's mechanical answer template without weakening the controls.

## Files

- [Run metadata](./00-run-metadata.md)
- [Policy one-pager](./01-policy-one-pager.md)
- [Pre-committed rubric](./02-scoring-rubric.md)
- [Frozen evaluation set](./03-fixed-evaluation-set.md)
- [Prompts](./prompts/)
- [Raw runs](./raw-runs/)
- [CSV run log](./results/run-log.csv)
- [Version summary](./results/version-summary.md)
- [Change log](./analysis/change-log.md)
- [V4 ship gate](./analysis/v4-ship-gate.md)
- [Complete Markdown submission](./solution/complete-submission.md)
- `submission/assignment-03-evaluation-tracker.xlsx` - equivalent run-tracking workbook
- `submission/tracking-dashboard.png` - rendered workbook dashboard

## Reproducibility note

The model was **GPT-5.6 Thinking (ChatGPT)**. ChatGPT does not expose a numerical temperature, so the submission records it as platform-managed. The proposed v4 gate requires API reruns with explicit parameters before production release.
